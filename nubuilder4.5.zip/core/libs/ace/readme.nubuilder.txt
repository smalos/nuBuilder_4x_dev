Source: https://github.com/ajaxorg/ace-builds
Removed unnecessary files. 2021-01-25 / kev1n